Sanitized diagnostic extract for MaaAssistantArknights issue #18786

Included:
- config/schedule-config.json: only timer, wake-up, sleep-blocking, and post-action settings.
- debug/schedule-timeline.log: only scheduler, wake-up, sleep-management, countdown, and hibernate events from 2026-10-19 through 2026-10-21.

Removed instead of redacted in place:
- notification addresses and encrypted notification credentials
- account names, configuration/profile names, and unrelated identifiers
- cache files, avatars, screenshots, recognition images, and unrelated task/Core logs
- unrelated historical log lines

Redacted in retained content:
- scheduled-task identifier suffixes
- Windows user-profile paths
- email addresses (defense in depth)

The retained timestamps and event ordering are unchanged.
